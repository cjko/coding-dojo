from __future__ import unicode_literals

from django.db import models
import bcrypt, re

NAME_REGEX = re.compile(r'^[a-zA-Z.-]+$')
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
PW_REGEX = re.compile(r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$')
USERNAME_REGEX = re.compile(r'^(?=.{4,18}$)(?![_.])(?!.*[_.]{2})[a-zA-Z0-9._]+(?<![_.])$')

class UserManager(models.Manager):
	def register(self, postData):

		errors = []

		if len(postData['first_name']) < 1 or len(postData['last_name']) < 1 or len(postData['email']) < 1 or len(postData['first_name']) < 1:
			errors.append('Missing field.')

		if len(postData['first_name']) < 2 or len(postData['last_name']) < 2:
			errors.append('First name and/or last name cannot be fewer than 2 characters.')

		if not NAME_REGEX.match(postData['first_name']) or not NAME_REGEX.match(postData['last_name']):
			errors.append('First name and/or last name can only contain letters.')

		if not USERNAME_REGEX.match(postData['username']):
			errors.append('Username must be between 4-18 characters and begin with a letter.')

		if not EMAIL_REGEX.match(postData['email']):
			errors.append('Email is invalid.')

		if not PW_REGEX.match(postData['password']):
			errors.append('Password is invalid. Cannot be fewer than 8 characters.')

		if postData['password'] != postData['confirm_pw']:
			errors.append('Passwords do not match.')

		# search for email in database
		if User.objects.filter(email=postData['email']):
			errors.append('Email already exists.')

		if User.objects.filter(username=postData['username']):
			errors.append('Username already exists.')

		if len(postData['birthdate']) < 1:
			errors.append('Please enter your birthdate.')
		elif int(postData['birthdate'][0:4]) < 1900 or int(postData['birthdate'][0:4]) > 2016:
			errors.append('Invalid birthdate.')

		return errors

	def create_user(self, postData):
		hashed_pw = bcrypt.hashpw(postData['password'].encode('utf-8'), bcrypt.gensalt())

		new_user = User.objects.create(first_name=postData['first_name'], last_name=postData['last_name'], username=postData['username'], email=postData['email'], hashed_pw=hashed_pw, birthdate=postData['birthdate'])
		return new_user.id

	def login(self, postData):

		errors = []

		if not User.objects.filter(email=postData['email']):
			errors.append('Email and/or password are invalid.')
		else:
			if bcrypt.hashpw(postData['password'].encode('utf-8'), User.objects.get(email=postData['email']).hashed_pw.encode('utf-8')) != User.objects.get(email=postData['email']).hashed_pw:
				errors.append('Email and/or password are invalid.')

		return errors

class User(models.Model):
	first_name = models.CharField(max_length=255)
	last_name = models.CharField(max_length=255)
	username = models.CharField(max_length=16)
	email = models.CharField(max_length=255)
	birthdate = models.DateField()
	hashed_pw = models.CharField(max_length=255)
	created_at = models.DateTimeField(auto_now_add=True)
	updated_at = models.DateTimeField(auto_now=True)

	objects = UserManager()


class QuoteManager(models.Manager):

	def validate(self, postData):
		errors = []

		if len(postData['author']) < 4:
			errors.append('Author must be greater than 3 characters.')

		if len(postData['quote']) < 11:
			errors.append('Message must be greater than 10 characters.')

		if len(postData['author']) > 255:
			errors.append('Author name cannot be greater than 255 characters.')

		if len(postData['quote']) > 1000:
			error.append('Quote cannot be greater than 1000 characters.')

		return errors

	def create_quote(self, postData):
		Quote.objects.create(author=postData['author'], quote=postData['quote'], posted_by=User.objects.get(id=postData['user_id']))

	def favorite(self, postData):
		quote = postData['quote']
		user = User.objects.get(id=postData['user_id'])
		quote.favorites.add(user)
	def unfavorite(self, postData):
		quote = postData['quote']
		user = User.objects.get(id=postData['user_id'])
		quote.favorites.remove(user)


class Quote(models.Model):
	quote = models.TextField(max_length=1000)
	author = models.CharField(max_length=255)
	posted_by = models.ForeignKey(User)
	favorites = models.ManyToManyField(User, related_name="favorites")
	created_at = models.DateTimeField(auto_now_add=True)
	updated_at = models.DateTimeField(auto_now=True)

	objects = QuoteManager()

























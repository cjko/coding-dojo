from django.shortcuts import render, redirect
from django.contrib import messages
from models import User, Quote

# Create your views here.
def main(request):
	if 'user_id' in request.session:
		return redirect('/quotes')
	return render(request,'quotes/login.html')

def quotes(request):
	if 'user_id' in request.session:
		context = {
			'user': User.objects.get(id=request.session['user_id']),
			'quotes': Quote.objects.all()
		}

		return render(request, 'quotes/quotes.html', context)
	return redirect('/')

def contribute(request):
	if 'user_id' in request.session:
		quote = str(request.POST['quote'])

		if quote[0] == '"' or quote[0] == "'":
			quote = quote[1:len(quote)-1]
		if quote[len(quote)-1] == '"' or quote[len(quote)-1] == "'":
			quote = quote[1:len(quote)-2]

		postData = {
			'author': request.POST['author'],
			'quote': quote,
			'user_id': request.session['user_id'],
		}
		errors = Quote.objects.validate(postData)
		if not errors:
			Quote.objects.create_quote(postData)
			return redirect('/')

	for error in errors:
		messages.error(request, error)

	return redirect('/')

def favorite(request, quote_id):
	postData = {
		'quote': Quote.objects.get(id=quote_id),
		'user_id': request.session['user_id']
	}
	Quote.objects.favorite(postData)
	return redirect('/')

def unfavorite(request, quote_id):
	postData = {
		'quote': Quote.objects.get(id=quote_id),
		'user_id': request.session['user_id']
	}
	Quote.objects.unfavorite(postData)
	return redirect('/')

def show_user(request, user_id):
	context = {
		'user': User.objects.get(id=user_id),
		'quotes': Quote.objects.filter(posted_by=User.objects.get(id=user_id))
	}
	return render(request, 'quotes/user_info.html', context)

# PROCESS user registration
def register(request):
	postData = {
		'first_name': request.POST['first_name'],
		'last_name': request.POST['last_name'],
		'username': request.POST['username'],
		'email': request.POST['email'],
		'password': request.POST['password'],
		'confirm_pw': request.POST['confirm_pw'],
		'birthdate': request.POST['birthdate']
	}

	print postData['birthdate']


	# if no errors
	if not User.objects.register(postData):
		# add user to database
		new_user_id = User.objects.create_user(postData)
		request.session['user_id'] = new_user_id
		# messages.success(request, 'Successfully registered!')

		return redirect('/quotes')

	for error in User.objects.register(postData):
		messages.error(request, error)

	return redirect('/')

# PROCESS user login
def login(request):

	postData = {
		'email': request.POST['email'],
		'password': request.POST['password'],
	}

	#if no errors
	if not User.objects.login(postData):
		# find id matching email
		user_id = User.objects.get(email=postData['email']).id
		request.session['user_id'] = user_id
		# messages.success(request, 'Successfully logged in!')
		return redirect('/quotes')

	for error in User.objects.login(postData):
		messages.error(request, error)

	return redirect('/')

# REDIRECT to login and registration when logged out
def logout(request):
	request.session.clear()
	return redirect('/')

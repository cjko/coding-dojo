export class Note {
	constructor(private content: String = "") { }
}

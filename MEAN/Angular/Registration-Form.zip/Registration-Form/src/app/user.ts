export class User {
	constructor(
		first_name: string = "",
		last_name: string = "",
		email: string = "",
		password: string = "",
		confirm_pw: string = "",
		street_address: string = "",
		unit: string = "",
		city: string = "",
		state: string = "",
		feeling_lucky: boolean = null
	){

	}
}

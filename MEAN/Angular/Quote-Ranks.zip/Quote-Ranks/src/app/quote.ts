export class Quote {	
	constructor(quote:string="",author:string="",votes:number=0){}
}

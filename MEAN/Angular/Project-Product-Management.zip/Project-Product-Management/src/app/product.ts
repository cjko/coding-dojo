export class Product {
	
	constructor(title: string="", price: string="", imgurl: string=""){}
}

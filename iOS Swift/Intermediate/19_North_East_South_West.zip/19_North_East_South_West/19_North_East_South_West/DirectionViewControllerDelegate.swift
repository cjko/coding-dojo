//
//  DirectionViewControllerDelegate.swift
//  19_North_East_South_West
//
//  Created by Colin Jao on 5/17/17.
//  Copyright © 2017 Colin Jao. All rights reserved.
//

import UIKit

protocol DirectionViewControllerDelegate: class {
}

//
//  BeastedItemCell.swift
//  iOS_Black_Belt_Exam
//
//  Created by Colin Jao on 5/26/17.
//  Copyright © 2017 Colin Jao. All rights reserved.
//

import Foundation
import UIKit

class BeastedItemCell: UITableViewCell {
    @IBOutlet weak var beastedItemLabel: UILabel!
    @IBOutlet weak var beastedDate: UILabel!
}
